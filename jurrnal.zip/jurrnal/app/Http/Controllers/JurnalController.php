<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Jurnal; 
use App\Models\Mapel;

class JurnalController extends Controller
{
    public function index()
    {
        //get jurnals
        $jurnals = Jurnal::latest()->paginate(5);

        //render view with jurnals
        return view('jurnals.index', compact('jurnals'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $mapels = Mapel::all();

        return view('jurnals.create', compact('mapels'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate form data
        $request->validate([
            'id_mapel' => 'required',
            'kehadiran' => 'required', // Mengubah 'nilai' menjadi 'kehadiran'
            'materi' => 'required', // Menambah validasi untuk 'materi'
            'tanggal' => 'required|date', // Menambah validasi untuk 'tanggal'
        ]);
    
        // Create a new Jurnal instance
        Jurnal::create([
            'id_mapel' => $request->id_mapel,
            'kehadiran' => $request->kehadiran, // Menggunakan 'kehadiran' dari form
            'materi' => $request->materi, // Menggunakan 'materi' dari form
            'tanggal' => $request->tanggal, // Menggunakan 'tanggal' dari form
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('jurnals.index')->with('success', 'Data Jurnal Berhasil Disimpan!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Jurnal $jurnal)
    {
        $mapels = Mapel::all();

        return view('jurnals.edit', compact('jurnal', 'mapels'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Jurnal  $jurnal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Jurnal $jurnal)
    {
        // Validate form data
        $request->validate([
            'id_mapel' => 'required',
            'kehadiran' => 'required', // Mengubah 'nilai' menjadi 'kehadiran'
            'materi' => 'required', // Menambah validasi untuk 'materi'
            'tanggal' => 'required|date', // Menambah validasi untuk 'tanggal'
        ]);
    
        // Update Jurnal instance
        $jurnal->update([
            'id_mapel' => $request->id_mapel,
            'kehadiran' => $request->kehadiran, // Menggunakan 'kehadiran' dari form
            'materi' => $request->materi, // Menggunakan 'materi' dari form
            'tanggal' => $request->tanggal, // Menggunakan 'tanggal' dari form
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('jurnals.index')->with('success', 'Data Jurnal Berhasil Diperbarui!');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Jurnal  $jurnal
     * @return \Illuminate\Http\Response
     */
    public function destroy(Jurnal $jurnal)
    {
        $jurnal->delete();
 
        return redirect()->route('jurnals.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
