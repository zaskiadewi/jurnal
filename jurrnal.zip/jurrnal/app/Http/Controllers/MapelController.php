<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mapel;
use App\Models\Guru;

class MapelController extends Controller
{
    public function index()
    {
        //get posts
        $mapels = Mapel::latest()->paginate(5);

        //render view with posts
        return view('mapels.index', compact('mapels'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $gurus = Guru::all();

        return view('mapels.create', compact('gurus'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate form data
        $request->validate([
            'id_guru' => 'required',
            'nama_mapel' => 'required',
        ]);
    
        // Create a new Peminjaman instance
        Mapel::create([
            'id_guru' => $request->id_guru,
            'nama_mapel' => $request->nama_mapel,
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('mapels.index')->with('success', 'Data Mapel Berhasil Disimpan!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Mapel $mapel)
    {
        $gurus = Guru::all();

        return view('mapels.edit', compact('mapel', 'gurus'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Mapel $mapel)
    {
        // Validate form data
        $request->validate([
            'id_guru' => 'required',
            'nama_mapel' => 'required',
        ]);
    
        // Update Peminjaman instance
        $mapel->update([
            'id_guru' => $request->id_guru,
            'nama_mapel' => $request->nama_mapel,
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('mapels.index')->with('success', 'Data Mapel Berhasil Diperbarui!');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Mapel $mapel)
    {
        $mapel->delete();
 
        return redirect()->route('mapels.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
