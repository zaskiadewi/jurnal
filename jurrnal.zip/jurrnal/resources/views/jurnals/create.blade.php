<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tambah Data Jurnal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body style="background: lightgray">

    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <form action="{{ route('jurnals.store') }}" method="POST">
                        
                            @csrf

                            <div class="form-group">
                                <label class="font-weight-bold">MAPEL</label>
                                <select class="form-control @error('id_mapel') is-invalid @enderror" name="id_mapel">
                                    <option value="">Pilih Mapel</option>
                                    @foreach($mapels as $mapel)
                                        <option value="{{ $mapel->id }}">{{ $mapel->nama_mapel }}</option>
                                    @endforeach
                                </select>
                            
                                <!-- error message untuk id_mapel -->
                                @error('id_mapel')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">KEHADIRAN</label>
                                <select class="form-control @error('kehadiran') is-invalid @enderror" name="kehadiran" size="1">
                                    <option value="" selected disabled>~ Kehadiran~</option>
                                    <option value="XII PPLG" {{ (old('kehadiran') == 'HADIR') ? 'selected' : '' }}>HADIR</option>
                                    <option value="XII TJKT1" {{ (old('kehadiran') == 'TIDAK HADIR') ? 'selected' : '' }}>TIDAK HADIR</option>
                                    <option value="XII TJKT2" {{ (old('kehadiran') == 'TIDAK HADIR DI BERI TUGAS') ? 'selected' : '' }}>TIDAK HADIR DI BERI TUGAS</option>
                                </select>

                                <!-- error message untuk nama -->
                                @error('kehadiran')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">MATERI</label>
                                <textarea class="form-control @error('materi') is-invalid @enderror" name="materi" rows="5" placeholder="Masukkan Materi">{{ old('materi') }}</textarea>
                            
                                <!-- error message untuk materi -->
                                @error('materi')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">TANGGAL</label>
                                <input type="date" class="form-control @error('tanggal') is-invalid @enderror" name="tanggal" value="{{ old('tanggal') }}">
                            
                                <!-- error message untuk tanggal -->
                                @error('tanggal')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                            <button type="reset" class="btn btn-md btn-warning">RESET</button>

                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
